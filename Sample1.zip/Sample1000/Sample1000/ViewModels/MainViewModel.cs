﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Sample1000.ViewModels
{
    public class MainViewModel: Screen
    {

        public void inputMessage(string messageBox)
        {
            MessageBox.Show(string.Format("Hello {0}!", messageBox));
       
        }
      
    }

}
